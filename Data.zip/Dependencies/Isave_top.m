function Isave_top(object_name,k,sph_verts,verts,faces,genus,k_org,vert_idx,change_gen,Points)

save(object_name,'k','sph_verts','verts','faces','genus','k_org','vert_idx','change_gen','Points');

end