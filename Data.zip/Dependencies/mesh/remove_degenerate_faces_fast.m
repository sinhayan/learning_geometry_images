function [VV,FF] = remove_degenerate_faces_fast(V,F)
  % REMOVE_DEGENERATE_FACES Remove degenerate faces from a mesh (V,F)
  % this can make combinatorially manifold meshes into non-manifold ones, but
  % should not change the "carrier" solid of solid meshes.
  % 
  % [VV,FF] = remove_degenerate_faces(V,F)
  %
  % Inputs:
  %   V  #V by 3 list of vertex positions
  %   F  #F by 3 list of face indices into V
  % Outputs:
  %   VV  #VV by 3 list of vertex positions
  %   FF  #FF by 3 list of face indices into VV
  %


    % Snap exactly duplicate vertices
    [V,~,J] = remove_duplicate_vertices(V,0);
    F = J(F);
    % Remove combinatorially degenerate faces
    F = F(F(:,1)~=F(:,2) & F(:,2)~=F(:,3) & F(:,3)~=F(:,1),:);
    % remove vertices not in face list
    [unq_vert,~,F_un]=unique(F(:));
    vert_idx=ismember(1:size(V,1),unq_vert);
    
    V=V(vert_idx,:);
    F=reshape(F_un,size(F,1),size(F,2));
  VV = V;
  FF = F;
end
