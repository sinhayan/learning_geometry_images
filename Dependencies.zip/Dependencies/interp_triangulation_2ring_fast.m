function [disp_vertex2,bary_point]=interp_triangulation_2ring_fast(face,vertex1,vertex2,disp_vertex1,normal,face_index,index_all,tri_1_all, tri_2_all,tri_3_all,count_cell)




% barycentric



p=disp_vertex1(index_all,:);
proj_p=p-sum((p-vertex1(face(face_index,1),:)).*normal(face_index,:),2)*ones(1,3).*normal(face_index,:);

bary_point=barycentric_coordinates(proj_p,tri_1_all, tri_2_all,tri_3_all);
bary_point(isnan(bary_point))=1/3;

bary_min=(abs(sum(bary_point,2)-1));

bary_cell=mat2cell(bary_min,count_cell,1);
val = cellfun(@(x) find(x==min(x),1),bary_cell,'UniformOutput', false);
cum_cell=cumsum(count_cell);
val=cell2mat(val)';
val_b=[0,cum_cell(1:end-1)]+val;
val_face_b=bary_point(val_b,:);

val_face_b=val_face_b./(sum(val_face_b,2)*ones(1,3));
val_face=face_index(val_b);
tri_p=vertex2(face(val_face,:),:);
n=size(vertex2,1);
tri_1=tri_p(1:n,:);
tri_2=tri_p(n+1:2*n,:);
tri_3=tri_p(2*n+1:3*n,:);

disp_vertex2=(val_face_b(:,1)*ones(1,3)).*tri_1+(val_face_b(:,2)*ones(1,3)).*tri_2+(val_face_b(:,3)*ones(1,3)).*tri_3;




end
