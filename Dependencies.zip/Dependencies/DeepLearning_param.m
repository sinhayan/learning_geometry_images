function sph_verts=DeepLearning_plane(vert,face,maxvn,hier,n)





warning('off','MATLAB:singularMatrix')
sph_verts = initParamCALD_eff(vert, face ,1);
[~,val_int]=inverted_triangle(sph_verts,face);

% sph_verts=vert;
iter=1000;
[L,angles]=area_lap_eff(vert,face);
diag_val=1./diag(L);
diag_val(isinf(diag_val))=1;
L=sparse(1:size(L,1),1:size(L,1),diag_val,size(L,1),size(L,1))*L;
x=sph_verts;
for ii=1:iter
    x_mean=mean(x);
    x=x-ones(size(x,1),1)*x_mean;
    x=x./(sqrt(sum(x.^2,2))*ones(1,3));
    x=x-L*x;
    x=x./(sqrt(sum(x.^2,2))*ones(1,3));
end
[~,val_fin]=inverted_triangle(x,face);
if val_fin<val_int
    sph_verts=x;
end



A=calc_triangle_areas(vert, face, 'object', 'vertex');
A=A/sum(A);

A(A==0)=1e-2*min(A(find(A, 1 )));




N = normals(vert,face,'Stable',1);
N= N./(sqrt(sum(N.^2,2))*ones(1,3));
N(isnan(N))=0;

grad_face=cell(size(face,1),1);
for j=1:size(face,1)
    grad_mat=zeros(3);
    grad_mat(1,:)=vert((face(j,2)),:)-vert((face(j,1)),:);
    grad_mat(2,:)=vert((face(j,3)),:)-vert((face(j,2)),:);
    grad_mat(3,:)=N(j,:);
    grad_face{j}=grad_mat;
end

if size(L,1)<maxvn
    Linv=pinv(full(L));
else
    [V,D]=eigs(L,[],min(300,size(L,1)),-1e-5);
    [D,idx]=sort(diag(D));
    V=V(:,idx);
    Linv=V(:,2:end)*diag(1./D(2:end))*(V(:,2:end))';
end
[ring_2,ring]=compute_vertex_face_ring_2(face);

ang_cell=cell(size(vert,1),1);
for k=1:size(vert,1)
    face_adj=ring{k};
    ang_vert=zeros(length(face_adj),1);
    for kk=1:length(face_adj)
        idx_vert= find(face(face_adj(kk),:)==k);
        ang_vert(kk)= angles(face_adj(kk),idx_vert(1));
    end
    ang_cell{k}=ang_vert;
end


ring_type=1;
if ring_type==2
    face_index=cell2mat(ring_2);
    index_all=zeros(length(face_index),1);
    sum_index=0;
    for p=1:length(ring_2)
        index_all(sum_index+1:sum_index+length(ring_2{p}))=p;
        sum_index=sum_index+length(ring_2{p});
    end
    nn=length(face_index);
    vert_temp=face(face_index,:);
    tri_p=vert(vert_temp(:),:);
    tri_1_all=tri_p(1:nn,:);
    tri_2_all=tri_p(nn+1:2*nn,:);
    tri_3_all=tri_p(2*nn+1:3*nn,:);
    count_cell=cellfun('length',ring_2);
else
    face_index=cell2mat(ring);
    index_all=zeros(length(face_index),1);
    sum_index=0;
    for p=1:length(ring)
        index_all(sum_index+1:sum_index+length(ring{p}))=p;
        sum_index=sum_index+length(ring{p});
    end
    nn=length(face_index);
    vert_temp=face(face_index,:);
    tri_p=vert(vert_temp(:),:);
    tri_1_all=tri_p(1:nn,:);
    tri_2_all=tri_p(nn+1:2*nn,:);
    tri_3_all=tri_p(2*nn+1:3*nn,:);
    count_cell=cellfun('length',ring);
end

face_index_g=cell2mat(ring);
count_cell_g=cellfun('length',ring);



normal = cross(vert(face(:,1),:)-vert(face(:,2),:), vert(face(:,1),:)-vert(face(:,3),:));
normal= normal./(sqrt(sum(normal.^2,2))*ones(1,3));
normal(isnan(normal))=0;

if hier
    param=[0.02,0.01,0.001,0.005]*100/n;
    nn=round(n/length(param));
    for s=1:length(param)
        sph_temp=cell(nn,1);
        energy=zeros(nn,1);
        area_energy=zeros(nn,1);
        for i=1:nn
            
            
            A_s = compute_spherical_area_triangle(sph_verts, face);
            A_s=real(A_s);
            A_s=A_s/sum(A_s);
            
            lambda=A_s./A;
            
            
            delta=(lambda-1);
            
            energy(i)=sum(abs(delta));
            area_energy(i)=sum(abs(delta.*A));
            
            g=Linv*delta;
            
            g_eq=[g(face(:,2))-g(face(:,1)),g(face(:,3))-g(face(:,2)),zeros(size(face,1),1)];
            g_eq=g_eq';
            g_eq=mat2cell(g_eq,3,ones(size(g_eq,2),1));
            delta_g = cellfun(@(x,y) x\y, grad_face,g_eq','UniformOutput', false);
            delta_g=cell2mat(delta_g');
            delta_g =delta_g';
            delta_g(isnan(delta_g))=0;
            delta_g(isinf(delta_g))=max(max(delta_g(~isinf(delta_g))));
            
            val_g=delta_g(face_index_g,:);
            val_g=mat2cell(val_g,count_cell_g,3);
            
            g_vert=cellfun(@(x,y) sum((x.*(y*ones(1,3))),1)/sum(y),val_g,ang_cell,'UniformOutput', false);
            g_vert=cell2mat(g_vert);
            
            
            
            % displace vertex
            param_n=param(s)*max(max(vert))/max(max(g_vert));
            vert_disp=vert+(param_n).*g_vert;
            
            vert_disp(isnan(vert_disp))=vert(isnan(vert_disp));
            
            
            sph_verts_n=interp_triangulation_2ring_fast(face,vert,sph_verts,vert_disp,normal,face_index,index_all,tri_1_all, tri_2_all,tri_3_all,count_cell);
            
            
            sph_verts_n(isnan(sph_verts_n))=sph_verts(isnan(sph_verts_n));
            sph_verts=sph_verts_n;
            sph_verts= sph_verts./(sqrt(sum(sph_verts.^2,2))*ones(1,3));
            sph_temp{i}=sph_verts;
        end
        [~,idx]=min(area_energy);
        sph_verts=sph_temp{idx};
    end
    
else
    param_c=0.01*100/n;
    for i=1:n
        
        
        
        %           A_s = calc_triangle_areas(sph_verts, face, 'object', 'vertex');
        A_s = compute_spherical_area_triangle(sph_verts, face);
        A_s=real(A_s);
        A_s=A_s/sum(A_s);
        
        lambda=A_s./A;
        
        
        delta=(lambda-1);
        
        
        g=Linv*delta;
        
        g_eq=[g(face(:,2))-g(face(:,1)),g(face(:,3))-g(face(:,2)),zeros(size(face,1),1)];
        g_eq=g_eq';
        g_eq=mat2cell(g_eq,3,ones(size(g_eq,2),1));
        delta_g = cellfun(@(x,y) x\y, grad_face,g_eq','UniformOutput', false);
        delta_g=cell2mat(delta_g');
        delta_g =delta_g';
        delta_g(isnan(delta_g))=0;
        delta_g(isinf(delta_g))=max(max(delta_g(~isinf(delta_g))));
        
        val_g=delta_g(face_index_g,:);
        val_g=mat2cell(val_g,count_cell_g,3);
        
        g_vert=cellfun(@(x,y) sum((x.*(y*ones(1,3))),1)/sum(y),val_g,ang_cell,'UniformOutput', false);
        g_vert=cell2mat(g_vert);
        
        
        
        % displace vertex
        param_n=param_c*max(max(vert))/max(max(g_vert));
        vert_disp=vert+(param_n).*g_vert;
        
        vert_disp(isnan(vert_disp))=vert(isnan(vert_disp));
        
        
        sph_verts_n=interp_triangulation_2ring_fast(face,vert,sph_verts,vert_disp,normal,face_index,index_all,tri_1_all, tri_2_all,tri_3_all,count_cell);
        
        
        sph_verts_n(isnan(sph_verts_n))=sph_verts(isnan(sph_verts_n));
        sph_verts=sph_verts_n;
        sph_verts= sph_verts./(sqrt(sum(sph_verts.^2,2))*ones(1,3));
    end
    
    
    
    
    
end

end


