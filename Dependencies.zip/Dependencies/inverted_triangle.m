function [I,val]=inverted_triangle(vertex1,faces)

vertex1=vertex1';
faces=faces';


m = size(faces,2);
[~,normalf] = compute_normal(vertex1,faces);
% center of faces
C = squeeze(mean(reshape(vertex1(:,faces),[3 3 m]), 2));
% inner product
I = sum(C.*normalf);
val=sum(I(:)<0)/m;


end