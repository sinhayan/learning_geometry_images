% See kharmonic.m
%
% `harmonic` was stolen from gptoolbox by matlab's builtin double.harmonic in
% R2014a.
