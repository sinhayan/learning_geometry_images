function [L,M,totalarea,t2] = CotanLaplacianAreas(coord,tri)
%% adapted from the code of William Benjamin May 2008
%% vectorized and rewritten by Andrew Polk 2011

%number of eigenvectors/eigenvalues to compute
eigno = 300;
%error check
siz=size(coord);
siz2=size(tri);

if (siz(2)>siz(1))&&siz(1)==3
    coord=coord';
elseif (siz(2)>siz(1))&&siz(1)==2
    coord=[coord',zeros(siz(2),1)];
end
if (siz2(2)>siz2(1))&&siz2(1)==3
    tri=tri';
elseif (siz(2)>siz(1))&&siz(1)==2
    'that is crazy';
end

nopts = length(coord);

%% all vectors    
    v1 = coord(tri(:,1),:)-coord(tri(:,2),:);
    v2 = coord(tri(:,1),:)-coord(tri(:,3),:);
    v3 = coord(tri(:,2),:)-coord(tri(:,3),:);   
%% the length of all triangle edges
    d1=sqrt(sum((v1).^2,2));
    d2=sqrt(sum((v2).^2,2));
    d3=sqrt(sum((v3).^2,2));
%% the 3 angles for each triangle 
    angle1=acos(dot(v1,v2,2)./(d1.*d2));
    angle2=acos(dot(v1,-v3,2)./(d1.*d3));
    angle3=pi-angle1-angle2;
    angles=[angle2;angle1;angle3];
    t2=sum(0.5*d1.*d2.*sin(angle1));
%% cotangent Laplacian   
    TR1=tri(:,[1 3 2]); %used as indices to create adjacency matrix
    TR2=tri(:,[3 2 1]); %used as indices to create adjacency matrix
   
     L=sparse(double(TR1(:)),double(TR2(:)),cot(angles),nopts,nopts); %matlab magic!!
    %L=sparse(double(TR1(,double(TR2(,macot(angles)),nopts,nopts);
    L=(L+L')./2;%make symmetric
    D=sum(L,2);%include diagonal
    D(D==0)=1;
    L=L-spdiags(D,0,nopts,nopts);
   
%%
%The area of each vertex of the mesh is found as the area of the voronoi
%cell surrounding each vertex.
%this area is found as the sum of each vertexes "right triangle areas" and
%"left triangle Areas"
%A "right triangle area" for one vertex of one face is found from the law
%of sines where the radius of the circumscribed circle R is found from
%2R=a/sin(A).
%given the triangle a,b,c with opposite angles to a,b,c >> A,B,C
%The area of the right triangle is then given by Heron's formula
%A=1/8*sqrt((a+(R+R))*(R-(a-R))*(R+(a-R))*(a+(R-R)));
%A=1/8*a*sqrt(4R^2-a^2);
%%this only works for non obtuse triangles   
%% Radius of all circumscribed Circles
    R=d1./(2*sin(angle3));
%% "Right Areas" for the first,second, third vertices
    RA1=(d1./8).*sqrt(4*R.^2-d1.^2);
    RA2=(d3./8).*sqrt(4*R.^2-d3.^2);
    RA3=(d2./8).*sqrt(4*R.^2-d2.^2);
    Areas=1/2.*sqrt( (d1.^2).*(d3.^2)-((d1.^2+d3.^2-d2.^2)./2).^2);
    totalarea=sum(Areas);
    %% if an angle is obtuse use the right triangle area found from the the
    %% midpoint of the opposing side which is 1/4 the area of the total
    %% triangle.
    RA1(angle1>pi/2)=1/4.*Areas(angle1>pi/2);   
    RA2(angle1>pi/2)=0;
    RA3(angle1>pi/2)=RA1(angle1>pi/2);
   
    RA2(angle2>pi/2)=1/4.*Areas(angle2>pi/2);
    RA3(angle2>pi/2)=0;
    RA1(angle2>pi/2)=RA2(angle2>pi/2);
   
    RA3(angle3>pi/2)=1/4.*Areas(angle3>pi/2);   
    RA1(angle3>pi/2)=0;
    RA2(angle3>pi/2)=RA3(angle3>pi/2);
   
    RA=[RA1;RA2;RA3];
    RA=[RA;RA];
    TR1=tri(:,[1 2 3 2 3 1]);
    TR2=tri(:,[2 3 1 3 1 2]);
%      TR1=tri(:,[1 2 3]);
%     TR2=tri(:,[2 3 1]);
    AM=sparse(double(TR1(:)),double(TR2(:)),RA,nopts,nopts);    
    AM=full(sum(AM,2));
    AM(AM<1e-6)=mean(AM(AM>0));%for numerical stability extremely small areas are replaced with the mean area
      
%this contains areas for each vertex
M=spdiags(AM,0,nopts,nopts);
% mod

%%calculate eigens values and eigenvectors
%options=struct('disp',0);
M=4*pi*M/totalarea;
%M=M/totalarea;

% if flag ~= 0
%    errrrrrrror=1
% end
end
