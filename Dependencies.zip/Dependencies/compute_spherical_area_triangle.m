function areas = compute_spherical_area_triangle(vert,face )

A = face(:,1); B = face(:,2); C = face(:,3);

p1=vert(A,:);
p2=vert(B,:);
p3=vert(C,:);
% length of the sides of the triangles :
% cos(a)=p1*p2
a  = acos( dotp(p2,p3) );
b  = acos( dotp(p1,p3) );
c  = acos( dotp(p1,p2) );
s  = (a+b+c)/2;
% use L'Huilier's Theorem
% tand(E/4)^2 = tan(s/2).*tan( (s-a)/2 ).*tan( (s-b)/2 ).*tan( (s-c)/2 )
E = tan(s/2).*tan( (s-a)/2 ).*tan( (s-b)/2 ).*tan( (s-c)/2 );
A = 4*atan( sqrt( E ) );
A = real(A);
A=max(A,1e-20);
 areas = zeros(length(vert),1);
 count = zeros(length(vert),1);

% find all incident triangles upon each vertex and accumulate the areas of the triangles   
    for i=1:size(face,2)
        [u1, ~, n1] = unique(face(:,i));
        areas(u1) = areas(u1) + accumarray(n1, A);
        count(u1) = count(u1) + accumarray(n1, ones(length(n1),1));
    end
    
end



function d = dotp(x,y)
d = x(:,1).*y(:,1) + x(:,2).*y(:,2) + x(:,3).*y(:,3);
end